# PythonAnywhere Deployment Guide

## 📦 Files Included in ipl-dream11-deployment.zip

- `app.py` - Main Flask application
- `requirements.txt` - Python dependencies
- `instance/ipl_dream11.db` - SQLite database with all your data
- `static/` - CSS and JavaScript files
- `templates/` - HTML templates
- `update_rankings.py` - Helper script for bulk updates

## 🚀 Step-by-Step Deployment Instructions

### 1. Upload Files to PythonAnywhere

1. Go to [www.pythonanywhere.com](https://www.pythonanywhere.com) and log in
2. Click on **"Files"** tab
3. Upload the `ipl-dream11-deployment.zip` file
4. Open a **Bash console** from the "Consoles" tab
5. Navigate to your upload location and unzip:
   ```bash
   cd ~
   unzip ipl-dream11-deployment.zip -d ipl-dream11-2025
   cd ipl-dream11-2025
   ```

### 2. Install Dependencies

In the Bash console, create a virtual environment and install packages:

```bash
mkvirtualenv --python=/usr/bin/python3.10 ipl-env
pip install -r requirements.txt
```

### 3. Configure Web App

1. Go to **"Web"** tab
2. Click **"Add a new web app"**
3. Choose **"Manual configuration"**
4. Select **Python 3.10**
5. Click through to create the web app

### 4. Configure WSGI File

1. In the **Web** tab, scroll to **"Code"** section
2. Click on the **WSGI configuration file** link (e.g., `/var/www/yourusername_pythonanywhere_com_wsgi.py`)
3. Replace the entire content with:

```python
import sys
import os

# Add your project directory to the sys.path
project_home = '/home/yourusername/ipl-dream11-2025'
if project_home not in sys.path:
    sys.path.insert(0, project_home)

# Set environment variables
os.environ['APP_PASSWORD'] = 'admin123'  # Change this for security!

# Import your Flask app
from app import app as application
```

**⚠️ IMPORTANT:** Replace `yourusername` with your actual PythonAnywhere username!

### 5. Configure Virtualenv

1. In the **Web** tab, scroll to **"Virtualenv"** section
2. Enter the path to your virtualenv:
   ```
   /home/yourusername/.virtualenvs/ipl-env
   ```
3. **Replace `yourusername`** with your actual username

### 6. Configure Static Files

In the **Web** tab, scroll to **"Static files"** section and add:

| URL | Directory |
|-----|-----------|
| `/static/` | `/home/yourusername/ipl-dream11-2025/static/` |

**Note:** Replace `yourusername` with your actual username

### 7. Reload Web App

1. Scroll to the top of the **Web** tab
2. Click the big green **"Reload yourusername.pythonanywhere.com"** button
3. Wait a few seconds for the app to restart

### 8. Access Your App

Visit: `https://yourusername.pythonanywhere.com`

## 🔐 Security Notes

1. **Change the password:** In the WSGI file, change `admin123` to a secure password
2. **Or use environment variable:** Set `APP_PASSWORD` in your PythonAnywhere account settings

## 📊 Database Information

- **Database file:** `instance/ipl_dream11.db`
- **All your data is included:** matches, teams, settings, rankings
- **No additional setup needed** - the database is ready to use!

## ✅ Verify Deployment

1. Visit your app URL
2. You should see the home page with 11 completed matches
3. Try accessing **⚙️ Manage** (password: admin123 or your custom password)
4. Check **Match Rankings** to see all completed matches

## 🐛 Troubleshooting

### If you see "Something went wrong" or 502 error:

1. Go to **Web** tab → **Error log**
2. Check for errors
3. Common issues:
   - Wrong virtualenv path
   - Wrong project path in WSGI file
   - Missing dependencies (run `pip install -r requirements.txt` again)

### To view error logs:

```bash
# In Bash console
tail -f /var/log/yourusername.pythonanywhere.com.error.log
```

### To update rankings in the future:

```bash
cd ~/ipl-dream11-2025
source ~/.virtualenvs/ipl-env/bin/activate
python update_rankings.py
```

## 🔄 Updating Your App

When you make changes:

1. Upload new files via **Files** tab
2. Click **"Reload"** button in **Web** tab

## 📞 Support

- PythonAnywhere Help: [help.pythonanywhere.com](https://help.pythonanywhere.com)
- PythonAnywhere Forums: [www.pythonanywhere.com/forums](https://www.pythonanywhere.com/forums)

## 🎉 You're Done!

Your IPL Dream11 tracker is now live and accessible from anywhere!
